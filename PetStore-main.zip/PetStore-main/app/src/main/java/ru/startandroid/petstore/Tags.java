package ru.startandroid.petstore;

public class Tags {
    private int id;
    private String name;
}
